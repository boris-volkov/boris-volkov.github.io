# Handoff: Terminal-Style Essay Site

## Overview
A personal essay site for writing about **mathematics and education**, presented as an old-school UNIX computer terminal. Visitors land in a working command-line shell that auto-runs `ls -R` to print the full essay tree (topics → essays). They can browse by typing real commands (`ls`, `cd`, `cat`, `tree`, `help`, …) **or** just click any filename. Opening an essay launches a full-screen **vim-style reader buffer**; a `:q ‹ back` control returns to the listing. Two switchable looks: **dark** (default, modern flat) and **light** (paper).

## About the Design Files
The files in this bundle are **design references created in HTML** — a working prototype showing the intended look and behavior, **not production code to ship directly**. The included `.dc.html` uses a bespoke in-house "Design Component" runtime (`support.js`) that is specific to the prototyping environment; **do not** port that runtime. Your task is to **recreate this design in the target codebase's environment** (React, Vue, Svelte, plain TS, etc.) using its established patterns. If no codebase exists yet, pick the most appropriate stack — this is a small, self-contained client-side app with no backend; a single React/Vue component (or even vanilla TS) plus a content data structure is plenty.

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, chrome, and interactions are all specified below and should be recreated faithfully. The only thing that is placeholder is the essay prose itself (realistic sample content the author will replace).

---

## Architecture at a Glance
Three logical layers — keep them separate when you rebuild:

1. **Content model** — a virtual filesystem (tree of folders + essay files). Pure data.
2. **Shell** — command parser + scrollback log. Interprets typed commands and click actions, appends output rows.
3. **Reader** — a full-screen overlay that renders one essay as typeset prose. Independent of the shell scrollback.

Theme is a single enum (`dark | light`, default `dark`) that selects a color palette consumed by every layer.

---

## Content Model (virtual filesystem)

A 2-level tree: **topic folders → essay files**, plus one top-level `about.txt`.

```
~/
├── mathematics/
│   ├── on-mathematical-beauty.md      "On Mathematical Beauty"
│   ├── cantors-infinities.md          "Cantor and the Sizes of Infinity"
│   └── the-quadratic-formula.md       "Why We Teach the Quadratic Formula Wrong"
├── education/
│   ├── the-learning-styles-myth.md    "The Learning Styles Myth"
│   ├── in-praise-of-forgetting.md     "In Praise of Forgetting"
│   └── what-grades-measure.md         "What Grades Measure"
├── teaching/
│   ├── teaching-proof.md              "Teaching Proof to Beginners"
│   ├── the-problem-set.md             "Notes on the Problem Set"
│   └── notes-on-the-lecture.md        "Notes on the Lecture"
└── about.txt                          "about"
```

Suggested data shape (recreate in your stack — TS shown):

```ts
type Node =
  | { type: 'dir'; children: Record<string, Node> }
  | { type: 'file'; essay: Essay };

interface Essay {
  title: string;
  date?: string;     // "2026.03.02"
  read?: string;     // "4 min"
  blocks: Block[];
}
interface Block { t: 'p' | 'q'; text: string; }  // p = paragraph, q = pull-quote
```

- **Sort order** in any directory listing: directories first, then files, each group alphabetical.
- Math is written as **inline Unicode** in the prose (e.g. `e^(iπ) + 1 = 0`, `ℵ₀`, `√(b² − 4ac)`). There is no LaTeX/MathJax dependency. If the author later wants real typeset math, swap the reader's paragraph renderer for a KaTeX-aware one — note this as a future option, not a current requirement.
- Full essay text lives in `Essays Terminal.dc.html` inside the `fs = { … }` object on the logic class. Lift the prose verbatim from there.

---

## Screens / Views

### 1. Shell (the terminal)

**Purpose:** Browse the essay tree and issue commands.

**Layout**
- Page: full viewport, flex-centered, `padding: 24px`, background = theme `page` color.
- **Screen**: flex column, `max-width: 1040px`, `height: calc(100vh - 48px)`. Background = theme `screen` color. `border: 1px solid <border>; border-radius: 2px; box-shadow: 0 1px 3px rgba(0,0,0,.18);`. Font `'JetBrains Mono'`, monospace fallback, `font-size: 14.5px`.
- **Body** (scrollback): `flex: 1; overflow: auto; padding: 16px 18px 22px;`. Content column `max-width: 88ch`.
- **Status line** (bottom, vi/tmux modeline): `height: 25px; font-size: 12px;` reverse-video. Left: a filled chip `guest@essays`, then current path `~/…`. Right: two theme buttons `dark` `light` (active one filled).

**Scrollback rows.** Every command's output is a list of rows; each row is a list of styled segments (spans). Row kinds:
- `line` — `white-space: pre; line-height: 1.55;`
- `tree` — same as line (used for tree connectors)
- `prose` — `white-space: pre-wrap; line-height: 1.78; max-width: 70ch;` (used by the old inline `cat`, now superseded by the Reader; keep for typed fallback if you like)
- `blank` — `height: 0.82em;` spacer

**Prompt line** (always last): segments `user@host` + `:` + `~/path` + `$ ` + typed input + blinking block cursor. Implement the input as a **transparent `<input>` overlaid on styled text** so the rendered prompt controls all coloring while a real input field captures keystrokes (caret hidden; a CSS block cursor blinks at the end). Clicking anywhere in the shell focuses this input.

### 2. Reader (vim-style essay buffer)

**Purpose:** Read one essay distraction-free.

**Layout** — absolute overlay over the screen, `z-index: 5`, flex column, background = theme `screen`.
- **Scroll area**: `flex: 1; overflow: auto; padding: 40px 28px 56px;`. Inner column `max-width: 70ch; margin: 0 auto;`.
  - **Kicker** (breadcrumb): `topic / filename.md`, uppercase, `font-size: .82em; letter-spacing: .06em;` color = `meta`, `margin-bottom: 14px`.
  - **Title**: `font-size: 1.65em; font-weight: 700; line-height: 1.22;` color = `heading`, `margin-bottom: 11px`.
  - **Meta**: `date · read`, italic, `font-size: .92em;` color = `meta`, `margin-bottom: 20px`.
  - **Rule**: 1px line, color = `border`, `margin-bottom: 28px`.
  - **Paragraphs**: `white-space: pre-wrap; line-height: 1.85; font-size: 1.02em; margin: 0 0 1.2em;` color = `base`.
  - **Pull-quote block** (`t:'q'`): same but italic (color = `quote`) with `padding-left: 16px; border-left: 2px solid <border>;`.
  - **Signature** (only for `.md` files): `— guest`, color = `dim`, `margin-top: 6px`.
- **Reader status line** (bottom, `height: 25px`): left = filled `NORMAL` chip + ` "~/topic/file.md" [readonly]`; right = read-time + a filled clickable **`:q ‹ back`** button.

**Reader keyboard map** (focus the overlay on open):
- `q` / `Esc` → close, return to shell, refocus prompt
- `j` / `↓` → scroll +60px; `k` / `↑` → −60px
- `g` → top; `G` → bottom
- `Space` / `PageDown` → +90% viewport; `b` / `PageUp` → −90% viewport

---

## Interactions & Behavior

**Boot.** On load: print a 3-line banner (`guest@essays — essays on mathematics & education`, a hint line, blank), then automatically execute `ls -R` so the full tree is visible immediately. Then focus the prompt.

**Commands** (parse: trim → split on whitespace → `cmd` + `args`):
- `ls [-R] [dir]` — list a directory. `-R` prints the recursive tree with `├──`/`└──`/`│` connectors. No arg = current dir.
- `tree [dir]` — same as `ls -R`.
- `cd <dir>` — change directory. Supports `..`, `~`, `/`, and paths. Errors: `no such file or directory`, `not a directory`.
- `cat <file>` / `open` / `read` — **open the Reader** for that essay. Errors: missing operand, no such file, is a directory.
- `pwd` — print current path.
- `whoami` — short author blurb + essay count.
- `about` — opens `about.txt` in the Reader.
- `theme <crt|dark|light>` — switch look; echoes `theme → <name>`. Bad arg → usage error.
- `clear` — empty the scrollback.
- `help` — formatted command list + tips line.
- `date` — current date string.
- Unknown → `<cmd>: command not found` + `type 'help' for a list of commands` (error color).

**Tab completion.** On `Tab`: if completing the first word, match against the command list. If completing an argument, match against entries in the current directory (filtered to dirs for `cd`, to files for `cat`/`open`/`read`). Single match → fill it in (append `/` for dirs, space after a completed command). Multiple → echo the candidates and fill the longest common prefix.

**Command history.** `↑`/`↓` walk previously entered (non-empty) commands into the input. Resets on edit/submit.

**Clicking vs typing — important distinction (recently fixed):**
- **Clicking a filename** in the listing opens the Reader **directly with no echo** — a mouse user must never see a phantom `cat …` line they didn't type.
- **Clicking a folder** runs `cd ~/<path>` (this one *does* echo, like a typed command — it changes shell state).
- **Typing** `cat <file>` echoes the command normally, then opens the Reader.
- Implementation note: clickable file segments carry the intended `cat ~/path` action; the click handler detects the `cat ` prefix and routes to "open reader (silent)" instead of "exec".

**Clickable affordance.** Directory and file names in listings are clickable: `cursor: pointer;` + `.clk:hover { text-decoration: underline; filter: brightness(1.3); }`.

**Animations / transitions:**
- Cursor blink: `@keyframes blink {0%,49%{opacity:1} 50%,100%{opacity:0}}`, `1.05s steps(1) infinite`.
- `.clk` hover: `transition: filter .1s ease;`

**Auto-scroll.** After any command output, scroll the shell body to the bottom.

---

## State Management
- `theme: 'crt' | 'dark' | 'light'` — selected look (default `crt`).
- `cwd: string[]` — current directory path segments (e.g. `['mathematics']`).
- `input: string` — current prompt text.
- `log: Row[]` — scrollback (array of row objects).
- `hist: string[]` + `histIdx: number` — command history and cursor.
- `openFile: { segs, node } | null` — when non-null, the Reader is open for that essay.

Transitions: commands push rows to `log` and may set `cwd`/`theme`; `cat`/file-click sets `openFile`; reader close sets `openFile = null`. No data fetching — everything is in-memory.

---

## Design Tokens

**Type**
- Font: `'JetBrains Mono'` (Google Fonts), fallback `ui-monospace, Menlo, Consolas, monospace`. Weights 400/500/700; italic used for meta/quotes.
- Base shell size `14.5px`. Reader scales relative (`em`) — title `1.65em`, body `1.02em`, kicker `.82em`.

**Palette — `dark`** (default, modern flat)
- page `#0b0d10` · screen `#0e1116` · border `#20242b`
- base `#d6dbe2` · dim `#6b7280` · dir `#6cb6ff` · file `#aeb6c2` · heading `#d2a8ff`
- meta `#6b7280` · path `#6cb6ff` · sym `#6b7280` · error `#ff7b72` · quote `#8a93a0` · accent `#7ee787` · cursor `#7ee787`
- status: bg `#161b22` · fg `#8b949e` · chip-bg `#238636` · chip-fg `#eafff0`
- no glow, no bezel, no scanlines

**Palette — `light`** (paper)
- page `#dcd8cc` · screen `#f5f2e9` · border `#d6d0c0`
- base `#33302a` · dim `#8a8472` · dir `#1f6fb2` · file `#33302a` · heading `#7a4ca6`
- meta `#8a8472` · path `#1f6fb2` · sym `#a39c88` · error `#b3402e` · quote `#7a7464` · accent `#4f7a28` · cursor `#33302a`
- status: bg `#2b2b28` · fg `#cfc9ba` · chip-bg `#f5f2e9` · chip-fg `#2b2b28`

**Segment role → style** (how scrollback colors map)
- `dir` → color `dir`, weight 600 · `file` → color `file` · `heading` → `heading`, weight 700
- `meta` → `meta`, italic · `dim` → `dim` · `quote` → `quote`, italic · `accent` → `accent`, weight 600
- `prompt-user` → `promptUser`, weight 600 · `prompt-path` → `path` · `sym` → `sym` · `error` → `error`, weight 600

**Chrome metrics**
- Status line height `25px`, font `12px`. Status chips: full-height, `padding: 0 11px`.
- Screen border radius `2px`.

---

## Assets
- **Font:** JetBrains Mono via Google Fonts (`https://fonts.googleapis.com/css2?family=JetBrains+Mono:ital,wght@0,400;0,500;0,700;1,400`). No image assets, no icons — all chrome is CSS. Tree connectors and box-drawing use Unicode glyphs (`├ └ │ ─ ┌ ┐ ‹ ·`).

## Files
- `Essays Terminal.dc.html` — the full prototype. The `<x-dc>` template (markup) and the `class Component` logic block hold everything: the `fs` content tree, command engine, completion/history, reader, and all theme palettes. **This is the source of truth** — lift content and exact values from here.
- `support.js` — the prototyping runtime that renders the `.dc.html`. **Reference only; do not port.** It explains how the template binds to the logic class but is not part of the design.

## Recreation checklist
1. Model the `fs` tree as data; copy the essay prose verbatim from the prototype.
2. Build the command engine (parser + the commands above) writing rows into a scrollback log.
3. Render scrollback as styled monospace segments; wire clickable dirs (→ `cd`, echoes) and files (→ open reader, silent).
4. Build the prompt with a transparent input + styled overlay + blinking cursor; add Tab-complete and history.
5. Build the full-screen Reader with the vim keymap and modeline.
6. Implement the two theme palettes behind one enum; default `dark`.
7. Auto-run the banner + `ls -R` on boot.
